
// year
document.getElementById('y').textContent = new Date().getFullYear();

// i18n strings
const strings = {
  en: {
    nav_home: "Home", nav_services: "Services", nav_portfolio: "Work",
    nav_pricing: "Pricing", nav_about: "About", nav_contact: "Contact",
    hero_title: "We build fast, modern websites that win clients",
    hero_sub: "Design, SEO and security tailored for small businesses.",
    hero_cta: "Start a project", hero_work: "See our work",
    svc_title: "What we do",
    svc_web_title: "Website Design", svc_web_desc: "Landing pages, business sites, online booking and more — crafted for speed and conversion.",
    svc_seo_title: "SEO & Security", svc_seo_desc: "On‑page SEO, performance audits, analytics, backups and protection.",
    svc_sm_title: "Social Media", svc_sm_desc: "Content plans and visuals to support your brand.",
    portfolio_title: "Recent Work",
    p1_title: "Clean Landing Page", p1_tag: "HTML/CSS",
    p2_title: "Restaurant Menu", p2_tag: "Responsive",
    p3_title: "Portfolio Grid", p3_tag: "Gallery",
    pricing_title: "Transparent Pricing",
    plan_basic: "Starter", plan_pro: "Business", plan_custom: "Custom",
    plan_contact: "Talk to us",
    plan_item1: "One‑page site", plan_item2: "Basic SEO", plan_item3: "1 week delivery",
    plan_item4: "Multi‑page website", plan_item5: "SEO + Analytics", plan_item6: "CMS + Forms",
    plan_item7: "E‑commerce / Booking", plan_item8: "Integrations", plan_item9: "Priority support",
    about_title: "About FS Studio",
    about_text: "We are a small studio focused on practical, high‑quality websites for local and online businesses.",
    contact_title: "Contact",
    contact_note: "We work online — please message us via WhatsApp or the form.",
    form_name: "Name", form_msg: "Message", form_send: "Send",
    f_privacy: "Privacy", f_terms: "Terms", f_impressum: "Impressum",
    thanks: "Thanks! We will get back to you shortly."
  },
  de: {
    nav_home: "Start", nav_services: "Leistungen", nav_portfolio: "Arbeiten",
    nav_pricing: "Preise", nav_about: "Über uns", nav_contact: "Kontakt",
    hero_title: "Wir erstellen schnelle, moderne Websites, die Kunden gewinnen",
    hero_sub: "Design, SEO und Sicherheit – passgenau für kleine Unternehmen.",
    hero_cta: "Projekt starten", hero_work: "Referenzen ansehen",
    svc_title: "Was wir anbieten",
    svc_web_title: "Webdesign", svc_web_desc: "Landingpages, Firmenwebsites, Online‑Terminbuchung – optimiert für Geschwindigkeit und Conversion.",
    svc_seo_title: "SEO & Sicherheit", svc_seo_desc: "On‑Page‑SEO, Performance‑Checks, Analytics, Backups und Schutz.",
    svc_sm_title: "Social Media", svc_sm_desc: "Content‑Pläne und Grafiken für Ihre Marke.",
    portfolio_title: "Ausgewählte Projekte",
    p1_title: "Klare Landingpage", p1_tag: "HTML/CSS",
    p2_title: "Restaurant‑Menü", p2_tag: "Responsiv",
    p3_title: "Portfolio‑Grid", p3_tag: "Galerie",
    pricing_title: "Transparente Preise",
    plan_basic: "Starter", plan_pro: "Business", plan_custom: "Individuell",
    plan_contact: "Kontakt aufnehmen",
    plan_item1: "Ein‑Seiten‑Website", plan_item2: "Basis‑SEO", plan_item3: "Lieferung in 1 Woche",
    plan_item4: "Mehrseitige Website", plan_item5: "SEO + Analytics", plan_item6: "CMS + Formulare",
    plan_item7: "E‑Commerce / Buchung", plan_item8: "Integrationen", plan_item9: "Priorisierter Support",
    about_title: "Über FS Studio",
    about_text: "Wir sind ein kleines Studio und erstellen pragmatische, hochwertige Websites für lokale und Online‑Unternehmen.",
    contact_title: "Kontakt",
    contact_note: "Wir arbeiten online – bitte schreiben Sie uns per WhatsApp oder über das Formular.",
    form_name: "Name", form_msg: "Nachricht", form_send: "Senden",
    f_privacy: "Datenschutz", f_terms: "AGB", f_impressum: "Impressum",
    thanks: "Danke! Wir melden uns in Kürze."
  }
};

let curLang = "en";
const applyI18n = () => {
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    el.textContent = strings[curLang][key] || key;
  });
  document.documentElement.lang = curLang;
  document.getElementById("btn-en").classList.toggle("active", curLang==="en");
  document.getElementById("btn-de").classList.toggle("active", curLang==="de");
};
document.getElementById("btn-en").addEventListener("click", ()=>{curLang="en";applyI18n();});
document.getElementById("btn-de").addEventListener("click", ()=>{curLang="de";applyI18n();});
applyI18n();
